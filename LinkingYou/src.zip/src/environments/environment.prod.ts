export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyCYFyZipVvsLmNukWB2yyglfH_dWwNY660',
    authDomain: 'overclockwebapp.firebaseapp.com',
    databaseURL: 'https://overclockwebapp.firebaseio.com',
    projectId: 'overclockwebapp',
    storageBucket: 'overclockwebapp.appspot.com',
    messagingSenderId: '739798866467',
    appId: '1:739798866467:web:426f2a0ab1bf524aa12f96',
    measurementId: 'G-T3JW9E9WBM'
  }
};
