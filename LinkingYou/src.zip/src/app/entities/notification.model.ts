export interface Notification {
    csi: string;
    message: string;
}
