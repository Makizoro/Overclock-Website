export interface Subscription {
    csi: string;
    userId: string;
    docId: string;
}
