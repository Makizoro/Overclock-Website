export interface Forum {
    csi: string;
    topic: string;
}
