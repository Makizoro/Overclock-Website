export interface Event {
    name: string;
    date: string;
    description: string;
    externalLink: string;
    image: string;
    venue: string;
    csi: string;
}
