export interface Person {
  username: string;
  email: string;
  password: string;
  csiName: string;
  type: string;
}
