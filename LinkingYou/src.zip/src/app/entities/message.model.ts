export interface Message {
    message: string;
    timestamp: string;
    username: string;
}
